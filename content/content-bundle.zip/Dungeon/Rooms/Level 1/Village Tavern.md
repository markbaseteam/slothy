---
title: Village Tavern
created-date: 2023-02-01
modified-date: NaN
type: Room
roomref: 1-2
tags: 
- #Dungeon23
- #Room
- #Room1-2
- #Level1 
- #Tavern

Published: true
---
# Village Tavern

## Layout


## Description



## NPCs

## Monsters


## Connected Rooms


## Tags

#Dungeon23 #Room
---
title: Market Square
created-date: 2023-01-30
modified-date: NaN
type: Room
roomref: 1-1
tags: 
- #Dungeon23
- #Room
- #Level1
- #Room1-1
Published: true
---
# Market Square

## Layout
![[1-1marketsquare.png]]
## Description
The abandoned village square is a forgotten and desolate place, a haunting reminder of a once-thriving community. Overgrown weeds crack through the cobblestones, and rickety market stalls stand empty and forsaken some with fruit and vegetables rotting in their boxes . The once-sturdy stone well in the center of the square has crumbled into disrepair, its waters now murky and still. The tavern that once offered a warm fire and a merry tune now stands silent and boarded up, its roof caving in and windows shattered. The air is thick with the musty scent of decay, and the only sounds that can be heard are the mournful creaks of wooden beams and the distant rustling of rodents. The ghosts of the past seem to linger here, their memories and laughter now nothing more than echoes in the wind. The abandoned village square is a sad and eerie place, a testament to the transience of life and the inevitability of decline.


## Connected Rooms



## NPCs

## Monsters

## Tags

#Dungeon23 #Room #room1-1 #Level1 
---
title: Five Kings Mountain Information
created-date: 2023-01-23
modified-date: <%+ tp.file.last_modified_date("YYYY-MM-DD") %>
type: Location
tags: 
- #Dungeon23 
- #location
- #Golarion 
- #pathfinder
- #Paizo 
- #World_Location
- ##FiveKingsMountain
Published: true
---
_See also: [Five Kings Range](https://pathfinderwiki.com/wiki/Five_Kings_Range "Five Kings Range")_

## Inhabitants

The Five Kings Mountains is a [dwarven](https://pathfinderwiki.com/wiki/Dwarf "Dwarf") territory. The mountains are mostly rocky with occasional plateaus, and are home to savage [giants](https://pathfinderwiki.com/wiki/Giant "Giant") and bloodthirsty wildlife. Outsiders see very few natural resources worth the danger to exploit. The border nations don't establish settlements any closer than the foothills or approaching the dwarven territory, nor do they interfere with the industry carried out by the dwarves in the higher reaches, although they usually conduct a profitable trade with them. At the forested foothills, dwarven lumber mills work to procure timber and firewood to support tunneling operations and provide light and heat below the surface.[[4]](https://pathfinderwiki.com/wiki/Five_Kings_Range#cite_note-4)

## Geography



The Five Kings Mountains are a harsh and dangerous area. The mountains are mostly rocky with occasional plateaus. They are home to savage [giants](https://pathfinderwiki.com/wiki/Giant "Giant") and bloodthirsty wildlife, with few natural resources worth exploiting. The nations that surround the mountains (Druma, [Kyonin](https://pathfinderwiki.com/wiki/Kyonin "Kyonin"), [Galt](https://pathfinderwiki.com/wiki/Galt "Galt"), [Andoran](https://pathfinderwiki.com/wiki/Andoran "Andoran"), and [Isger](https://pathfinderwiki.com/wiki/Isger "Isger")) haven't establish settlements any closer than the foothills and don't approach the dwarven territory. They also do not interfere with the industry carried out by the stout folk in the higher reaches, although they usually conduct a profitable trade with the dwarves.[[11]](https://pathfinderwiki.com/wiki/Five_Kings_Mountains#cite_note-DG13-11) At the forested foothills, dwarven lumber-mills work to procure timber and firewood to support tunneling operations, and to provide light and heat below the surface.[[12]](https://pathfinderwiki.com/wiki/Five_Kings_Mountains#cite_note-12)[[13]](https://pathfinderwiki.com/wiki/Five_Kings_Mountains#cite_note-13)

Massive [iron gates](https://pathfinderwiki.com/wiki/Iron_Gates "Iron Gates") decorated with a huge dwarf faces carved above the entrance, guard all primary ways into to cities of the Five Kings Mountains. Smaller entrances located on high, otherwise inaccessible plateaus allow the stout folk to cultivate crops and provide grazing land for their herds. Additionally, a large number of iron-grated tunnels ensure that fresh air reaches even the deepest tunnels, and smoke and toxic gases can be safely vented away. Reservoirs have been built that catch the seasonal snow-melt and fill the subterranean cisterns with clear water.[[14]](https://pathfinderwiki.com/wiki/Five_Kings_Mountains#cite_note-DG15-14)

Underground, the dwarves have done miracles of engineering. Deep inside the mountains lie sprawling megalopolises that stretch the length of the [Five Kings Range](https://pathfinderwiki.com/wiki/Five_Kings_Range "Five Kings Range"). Nearly all dwarven settlements of the Five Kings Mountains are linked by long tunnels, though there are occasional tunnel collapses, or tunnels that are sealed on purpose, in places like [Droskar's Crag](https://pathfinderwiki.com/wiki/Droskar%27s_Crag "Droskar's Crag") or the sealed-off ancient city of [Saggorak](https://pathfinderwiki.com/wiki/Saggorak "Saggorak"). Dwarves are forced to travel above ground in these cases. The stout folk have constructed sturdy, iron gates throughout these tunnels, having learned their lesson during the orc invasions. The gates are usually open to help the travel between the cities. For safety reasons. the dwarven cities are arranged in dozens of discrete semi-autonomous caverns.[[14]](https://pathfinderwiki.com/wiki/Five_Kings_Mountains#cite_note-DG15-14) Tunnels and caverns are supported by enduring vaulted arches. The dwarven tunnels are well planned, smoothed, and rune-curved, and the halls and passages of the dwarven cavern-cities are hung with rich tapestries and banners to honor of their history, heroes, leaders, and gods.[[11]](https://pathfinderwiki.com/wiki/Five_Kings_Mountains#cite_note-DG13-11) Despite the ability of their race to see in the dark, most of the inhabited areas in the dwarven settlements are lit by oil lamps, tallow candles, torches, or magic spells, because the dwarves appreciate color and the play of light. Their mines are never lit with true fire due to the existence of explosive gases.[[14]](https://pathfinderwiki.com/wiki/Five_Kings_Mountains#cite_note-DG15-14)

## Reference

[Pathfinder Wiki - Five Kings Mountain](https://pathfinderwiki.com/wiki/Five_Kings_Mountains)


## Tags
#Dungeon23 #Maps #Golarion #pathfinder #Paizo #World_Location #FiveKingsMountain
---
title: World Map
created-date: 2023-01-21
modified-date: <%+ tp.file.last_modified_date("YYYY-MM-DD") %>
tags: 
- #Dungeon23, 
- #Maps, 
- #Golarion, 
- #pathfinder, 
- #Paizo
Published: true
---
# World Map
I am going to be basing my world on the Pathfinder world of Golarion, and using the area of the [Five Kings Mountains](https://pathfinderwiki.com/wiki/Five_Kings_Mountains), within the Shining Kingdoms

```leaflet  
id: Golarion-Region  
image: [[Golarion_highres.webp]]  
bounds: [[0,0], [1458, 1123]]  
lat: 729  
long: 562  
unit: miles  
scale: 1  
width: 95%  
height: 1000px  
zoomDelta: 0.5  
minZoom: 0  
maxZoom: 3  
defaultZoom: 0  
noScrollZoom: true  
recenter: true  
lock: true  
preserveAspect: true  
darkMode: false  
```


Here is a link the [Interactive Map of Golarion](https://oznogon.com/golarion/#6/35.645/-0.005) which has links to the Pathfinderwiki

## Tags

#Dungeon23 #Maps #Golarion #pathfinder #Paizo